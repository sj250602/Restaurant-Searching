
CREATE TABLE  IF NOT EXISTS cuisines (
    cuisines text NOT NULL,
    pork text,
    veg text,
    spicy text,
    lactose text,
    CONSTRAINT cuisines_key PRIMARY KEY (cuisines)
);

CREATE table IF NOT EXISTS rest(
    restaurant_id bigint NOT NULL,
    restaurant_name text,
    country text,
    city text,
    adress text,
    locality text,
    locality_verbose text,
    cuisines text,
    average_cost bigint,
    currency text,
    hastable text,
    hasonline text,
    isdelv text,
    aggre_rat float,
    rating_color text,
    rating_text text,
    votes integer,
    CONSTRAINT rest_key PRIMARY KEY (restaurant_id),
    CONSTRAINT rest_ref FOREIGN KEY (cuisines) references cuisines(cuisines)
);
